import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { splitAtColon } from '@angular/compiler/src/util';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.css']
})
export class HomePageComponent implements OnInit {
  @ViewChild('name') nameKey: ElementRef;
  constructor() { }

 
  ngOnInit(): void {}
    startTests() {
      localStorage.setItem('name', this.nameKey.nativeElement.value);
    } 
    
  }
