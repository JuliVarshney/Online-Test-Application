import { Component, OnInit, HostListener, IterableDiffers } from '@angular/core';
import { interval } from 'rxjs';
import { QuizServiceService } from 'src/app/services/quiz-service.service';
import { isNgTemplate } from '@angular/compiler';
import { element } from 'protractor';

@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css']
})
export class QuizComponent implements OnInit {

  public name: string = ''; 
  public correct1: string = '';
  public questionList: any = [];
  public pointsarr: any = [];
  public currentQuestion: number = 0;
  public points: number = 0;
  public unattemptedQuestion: number =0;
  counter = 40;
  correctAnswer: number = 0;
  inCorrectAnswer: number = 0;
  interval$: any;
  isQuizCompleted: boolean = false
  
  


  constructor(private quizService: QuizServiceService ) { }

  ngOnInit(): void {
    this.name = localStorage.getItem('name')!;
    this.getAllQuestions();
    this.startCounter();
    
  }
  getAllQuestions() {
    this.quizService
      .getQuestionJson()
      .subscribe((res: { questions: any }) => {
        this.questionList = res.questions;
      });
  }
 
  

    // answer with parameter of question and their options.
    answer(currentQno: number, option: any) {
      if (currentQno === this.questionList.length+1) {
        this.isQuizCompleted = true;
        this.stopCounter();
      }
      if(option.correct){
        this.correct1='true';
      }
      else if(!(option.correct)){
        this.correct1='false';
      }
    }
    
    nextQuestion() {  

      if (this.correct1=='true') {
        this.correctAnswer++; // correct answer count + 1
        this.points += 5; // increase by 5 points
      }
      // if wrong answer selected
      else if(this.correct1=='false') {
         // move to next question
          this.inCorrectAnswer++; // incorrect count + 1
          this.points -= 5; // substract 5 points
      }
      this.correct1=null;
          setTimeout(() => {
            this.currentQuestion++; // increase question count + 1
            this.resetCounter(); // reset timer
          //  this.getProgressPercent(); // increase progressbar %
          }, 1000);             
    }
    
  // Start counter
  startCounter() {
    if(this.currentQuestion <this.questionList.length||this.currentQuestion==0){
    this.interval$ = interval(1000) // interval is 1 sec
      .subscribe((val) => {
        this.counter--; // decrease 40 sec to 0sec
        if (this.counter == 0) {
          this.currentQuestion++; //increase question count + 1
          if(this.currentQuestion <this.questionList.length){
          this.counter = 40; // timer for 40 sec
          this.points -= 5; // if not answered within 40 sec it will take minus points
        }else{
          this.isQuizCompleted = true;
          this.stopCounter();
        }
      }
      });
    setTimeout(() => {
      this.interval$.unsubscribe(); // idle time limit for 10sec
    }, 1000000);
  }
  }
  // stop counter
  stopCounter() {
    this.interval$.unsubscribe();
    this.counter = 0;
  }
  // reset counter
  resetCounter() {
    this.stopCounter();
    this.counter = 40;
    this.startCounter();
  }  
}